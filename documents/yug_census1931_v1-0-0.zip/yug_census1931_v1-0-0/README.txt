************************************************************
Yugoslavia in 1931: The Census Data on the County/Town Level 
************************************************************

Greetings, 

This folder includes the census data file ("data.csv"), codebook for this dataset ("codebook.pdf") as well as the folder with a shapefile of Yugoslav counties ("shp"). 
The numeric identifier in the shapefile is identical to the one in the dataset, which allows you to combine the two files.

Best,
Milos

